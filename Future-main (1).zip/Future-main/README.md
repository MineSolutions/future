<div align="center">

# Future 2.13.5 (Free Edition)
  
<img src="https://crystalpvp.ru/future/logo.png" alt="logo" width="25%" />
<br> <br>
  
[clickgui pic](https://crystalpvp.ru/future/clickgui.png)
  
[click here to watch cattyn's video](https://www.youtube.com/watch?v=-wcOiZL6sXg)
  
mirrors:
  
[yougame.biz](https://yougame.biz/threads/277616) / [crystalpvp.ru](https://crystalpvp.ru/future) / [cattyn.dev](https://cattyn.dev/future)

[plutosolutions telegram](https://t.me/plutosolutions)
  
# [ info ]
  
It's almost Christmas and Santa came a bit early this year! And so, because you, anarchy players, were behaving very badly this year, you are receiving **COAL** for Christmas. Don't act surprised, if you still play anarchy 1 year after discovering it, you're already used to eating shit and receiving shitty presents, aren't you?

Since our first Konas crack people have been asking us to crack Future nonstop, and the reason why we weren't touching it is because there was no reason to do so.
RusherHack has a lot more useful utility mods than Future does and Future loses to 3arthh4ck in PvPs. RusherHack got cracked by us a week after we released the first Konas crack, and 3arthh4ck is free.
  
Not only that, but Future got worse over time. 0x22 started pasting features from 3arthh4ck and just making stuff worse, for example the GUI and HUD look like shit now ([click here for shitty comparison](https://crystalpvp.ru/future/comparison.png)). Then 0x22 got crystalpvp.cc server access and he started making serverside bypasses that only users with Future could do, so if you packetlogged Future's packetfly and just replaced some values in your packetfly code then your packetfly would magically start working again.

# [ how-to ]

</div>

## Official launcher

1. Download the crack installer from the [releases page](https://github.com/PlutoSolutions/Future/releases)
2. Run it with `java -jar Installer.jar` or by double-clicking it
3. Select your game path if it wasn't detected automatically
4. Select the minecraft profile to install Future into (profile should have a version with Forge installed)
5. Click checkboxes if you need baritone or optifine installed
6. Click install
7. Run the game

## MultiMC
1. Download the crack package from the [releases page](https://github.com/PlutoSolutions/Future/releases)
2. Install loader-1.0.jar by following [this video](https://youtu.be/-4XayCqZI1g?t=36) (after clicking edit paste stuff from future.json)
3. Do the same for tweaker-1.0.jar but after clicking edit paste stuff from tweaker.json
4. Make sure the tweaker comes before the loader ([like this](https://crystalpvp.ru/future/multimc.png))
5. Put auth_key into your %username%/Future folder (on windows it's C:/Users/%username%/Future/auth_key)
6. Run the game

## TL Legacy
1. Open the launcher and check your game directory ([look here](https://crystalpvp.ru/future/tlenglish.png))
2. Download the official 1.12.2 Forge installer ([from here](https://maven.minecraftforge.net/net/minecraftforge/forge/1.12.2-14.23.5.2859/forge-1.12.2-14.23.5.2859-installer.jar)) and run it
3. In that installer make sure the game directory is the same as the launcher one, press OK
4. Download the crack installer from the [releases page](https://github.com/PlutoSolutions/Future/releases)
5. Run it with `java -jar Installer.jar` or by double-clicking it, make sure the game path is set to the launcher path and choose the `forge` profile
6. Click checkboxes if you need baritone or optifine installed
7. Click install
8. Open the launcher, turn off "Ely.by skins" in the settings ([here](https://crystalpvp.ru/future/tl2english.png)), find game version "1.12.2-forge-14.23.5.2859" and run it

<div align="center">
  
# [ issues ]

If something fails then you might need to check your java installation. We recommend using corretto JDK 8 for running this

Get it [here](https://docs.aws.amazon.com/corretto/latest/corretto-8-ug/downloads-list.html)

# [ credits ]

</div>

+ [Kalju](https://github.com/pkalju), [0x22](https://github.com/0-x-2-2) - making the client
+ Friendly - Making the base of this client
+ [Steve From Minecraft](https://github.com/NUMBERONEMINECRAFTFAN) - cracking
+ [maywr](https://github.com/maywr) - assistance in reversing efforts
+ [mrnv](https://github.com/mr-nv) - help with JVMTI and ASM
+ [cattyn](https://github.com/cattyngmd) - moral support
